# 🎬 Movie Recommendation System

## 📌 Objective
Recommend movies to users based on their past ratings using collaborative filtering.

## 📁 Dataset
- MovieLens 100K Dataset
- Built-in from Surprise Library

## ⚙️ Algorithm Used
- Singular Value Decomposition (SVD)

## 📊 Evaluation Metrics
- RMSE (Root Mean Squared Error)
- MAE (Mean Absolute Error)

## 📦 Libraries Used
- scikit-surprise, pandas

## 📽 Demo Video
[Add your video link here]
