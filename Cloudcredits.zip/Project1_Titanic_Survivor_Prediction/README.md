# 🚢 Titanic Survivor Prediction

## 📌 Objective
Predict whether a passenger survived the Titanic disaster using features like age, gender, and class.

## 📁 Dataset
- Source: seaborn Titanic dataset (`sns.load_dataset('titanic')`)

## ⚙️ Algorithm Used
- Logistic Regression

## 🧪 Features Used
- `Pclass`, `Sex`, `Age`, `SibSp`, `Parch`, `Fare`, `Embarked`

## 📊 Evaluation Metrics
- Accuracy
- Precision
- Recall
- Confusion Matrix

## 📦 Libraries Used
- pandas, numpy, seaborn, matplotlib, scikit-learn

## 📽 Demo Video
[Add your video link here]
